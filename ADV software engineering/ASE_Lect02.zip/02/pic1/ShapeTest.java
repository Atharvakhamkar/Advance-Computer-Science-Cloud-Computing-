class ShapeTest {
  public static void main(String[] args) {

    Shape s = new Shape(0, 0);

    System.out.println(s);

    System.out.println("Drawing...");
    s.draw(null);
  }
}
